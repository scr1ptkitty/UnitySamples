﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class coin_script : MonoBehaviour {

    public Rigidbody myRig;
    Vector3 angleVelocity;

    void Start()
    {
        //Set the axis the Rigidbody rotates in (100 in the y axis)
        angleVelocity = new Vector3(0, 75, 0);

        //Fetch the Rigidbody from the GameObject with this script attached
        myRig = this.gameObject.GetComponent<Rigidbody>();
    }

    void FixedUpdate()
    {
        Quaternion deltaRotation = Quaternion.Euler(angleVelocity * Time.deltaTime);
        myRig.MoveRotation(myRig.rotation * deltaRotation);
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.name.Contains("Ball"))
        {
            Destroy(this.gameObject);

            int s = int.Parse(GameObject.Find("txtScoreValue").GetComponent<TextMesh>().text);
            s += 1;
            GameObject.Find("txtScoreValue").GetComponent<TextMesh>().text = s.ToString();
        }
    }
}
