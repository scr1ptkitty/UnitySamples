﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class god_script : MonoBehaviour
{
    public GameObject score, ball;
    public int ballsRemaining;
    

	// Use this for initialization
	void Start ()
    {
        /*for (int i = 0; i < 25; i++)
        {*/
            Vector3 newPos = new Vector3(Random.Range(-8.0f, 8.0f), 20, -1);
            GameObject.Instantiate(ball, newPos, Quaternion.identity);
       /* }*/
        
        ballsRemaining = 3;
        
	}
	
	// Update is called once per frame
	void Update ()
    {
		if (Input.GetKeyUp("space"))
        {
            if (ballsRemaining > 0 && GameObject.FindGameObjectsWithTag("Ball").Length == 0)
            {
                ballsRemaining--;
                Vector3 newPos = new Vector3(Random.Range(-8.0f, 8.0f), 20, -1);
                GameObject.Instantiate(ball, newPos, Quaternion.identity);
            }
        }
	}
}
