﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class paddle_script : MonoBehaviour
{
    public Rigidbody myRig;
    Vector3 angleVelocity;

    void Start()
    {
        //Set the axis the Rigidbody rotates in (100 in the y axis)
        angleVelocity = new Vector3(0, 0, 100);

        //Fetch the Rigidbody from the GameObject with this script attached
        myRig = this.gameObject.GetComponent<Rigidbody>();
    }

    void FixedUpdate()
    {
        Quaternion deltaRotation = Quaternion.Euler(angleVelocity * Time.deltaTime);
        myRig.MoveRotation(myRig.rotation * deltaRotation);
    }
}
