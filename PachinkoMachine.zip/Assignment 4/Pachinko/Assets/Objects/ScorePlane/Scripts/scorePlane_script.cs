﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class scorePlane_script : MonoBehaviour
{
    public GameObject ball;
    public GameObject god;
    public int blue, yellow, orange;
    // Use this for initialization
    void Start ()
    {
        blue = 0;
        yellow = 0;
        orange = 0;
    }
	
	// Update is called once per frame
	void Update ()
    {
		
	}

    private void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.name.Contains("Ball"))
        {
            Destroy(other.gameObject);

            if (this.gameObject.name == "SmallScorePlane")
            {
                orange++;
                Debug.Log("Orange: " + orange);

                int s = int.Parse(GameObject.Find("txtScoreValue").GetComponent<TextMesh>().text);
                s += 1;
                GameObject.Find("txtScoreValue").GetComponent<TextMesh>().text = s.ToString();

                Vector3 newPos = new Vector3(Random.Range(-8.0f, 8.0f), 20, -1);
                GameObject.Instantiate(ball, newPos, Quaternion.identity);

                newPos = new Vector3(Random.Range(-8.0f, 8.0f), 20, -1);
                GameObject.Instantiate(ball, newPos, Quaternion.identity);

                newPos = new Vector3(Random.Range(-8.0f, 8.0f), 20, -1);
                GameObject.Instantiate(ball, newPos, Quaternion.identity);
            }
            else if (this.gameObject.name == "SideScorePlane")
            {
                yellow++;
                Debug.Log("Yellow: " + yellow);
                int s = int.Parse(GameObject.Find("txtScoreValue").GetComponent<TextMesh>().text);
                s += 10;
                GameObject.Find("txtScoreValue").GetComponent<TextMesh>().text = s.ToString();
            }
            else
            {
                blue++;
                Debug.Log("Blue: " + blue);
                int s = int.Parse(GameObject.Find("txtScoreValue").GetComponent<TextMesh>().text);
                s += 5;
                GameObject.Find("txtScoreValue").GetComponent<TextMesh>().text = s.ToString();
            }
        }
    }
}
