﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BadGuyScript : MonoBehaviour
{
    public Rigidbody myRig;

	// Use this for initialization
	void Start ()
    {
        myRig = this.gameObject.GetComponent<Rigidbody>();
        myRig.velocity = new Vector3(-10, 0, 10);
    }
	
	// Update is called once per frame
	void Update ()
    {
        
	}

    private void OnCollisionStay(Collision collision)
    {
        if (collision.gameObject.name == "Wall")
        {
            myRig.velocity = new Vector3(Random.Range(-10.0f, 10.0f), 0, Random.Range(-10.0f, 10.0f));
        }
    }
}
