﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class checkYVal : MonoBehaviour
{
    public Rigidbody myRig;
	// Use this for initialization
	void Start ()
    {
        myRig = this.gameObject.GetComponent<Rigidbody>();
	}
	
	// Update is called once per frame
	void Update ()
    {
        Debug.Log(myRig.position.y);
	}
}
