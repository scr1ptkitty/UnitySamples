﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class forceScript : MonoBehaviour
{
    public Rigidbody myRig;
	// Use this for initialization
	void Start ()
    {
        myRig = this.gameObject.GetComponent<Rigidbody>();

        //myRig.AddForce(new Vector3(0, 1000, 0));
        myRig.AddExplosionForce(1000.0f, new Vector3(0, -1, 0), 100.0f);
        //myRig.velocity = new Vector3(0, 1000, 0);
	}
	
	// Update is called once per frame
	void Update ()
    {
		
	}
}
