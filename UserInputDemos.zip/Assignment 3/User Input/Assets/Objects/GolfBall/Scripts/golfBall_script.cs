﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class golfBall_script : MonoBehaviour
{

    public Rigidbody myRig; // will hold the player object's rigidbody
    float x;
    float y;
    float z;

    float tx; // trajectory x
    float tz; // trajectory z
    // Use this for initialization
    void Start()
    {
        myRig = this.gameObject.GetComponent<Rigidbody>(); // get the Rigidbody of the object this script is attached to
        // If there is no Rigidbody attached, myRig would be null

        x = myRig.position.x;
        z = myRig.position.z;

        

    }

    // Update is called once per frame
    void Update ()
    {
		
	}

    private void OnMouseDown()
    {
       //     Debug.Log("Clicked the golf ball");
        x = myRig.position.x;
        z = myRig.position.z;
    }

    private void OnMouseUp()
    {
        //    Debug.Log("Dragged the golf ball");
        // starting position
        tx = Input.mousePosition.x;
        tz = Input.mousePosition.z;

        float dist = Mathf.Sqrt( ((x-tx)*(x-tx)) + ((z-tz)*(z-tz)) );
            Debug.Log("Distance dragged: " + dist);

        myRig.velocity = new Vector3(tx-x, 0, tz-z);
    }

    
}
