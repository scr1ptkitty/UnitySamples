﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class marble_script : MonoBehaviour {

    // constructor
    public marble_script()
    {

    }

    public Rigidbody myRig; // will hold the player object's rigidbody

    // Use this for initialization
    void Start()
    {
        myRig = this.gameObject.GetComponent<Rigidbody>(); // get the Rigidbody of the object this script is attached to
        // If there is no Rigidbody attached, myRig would be null
    }

    // Update is called once per frame
    void Update ()
    {
        myRig.velocity = (new Vector3(myRig.velocity.x + Input.GetAxis("Horizontal"), myRig.velocity.y, myRig.velocity.z + Input.GetAxis("Vertical")));
	}

    private void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.name == "Wall")
        {
            myRig.position = new Vector3(0, 1, 0);
        }
    }
}
