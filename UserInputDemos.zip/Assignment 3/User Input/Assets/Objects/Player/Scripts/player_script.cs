﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class player_script : MonoBehaviour
{

    // constructor
    public player_script()
    {

    }

    public Rigidbody myRig; // will hold the player object's rigidbody
    public bool hasJumped;

    // Use this for initialization
    void Start()
    {
        myRig = this.gameObject.GetComponent<Rigidbody>(); // get the Rigidbody of the object this script is attached to
        hasJumped = false;
        // If there is no Rigidbody attached, myRig would be null
    }

    // Update is called once per frame
    void Update()
    {
        myRig.velocity = new Vector3(Input.GetAxis("Horizontal") * 4, myRig.velocity.y, 0);

        if (Input.GetAxis("Jump") != 0)
        {
            if (hasJumped == false)
            {
                myRig.velocity = new Vector3(myRig.velocity.x, Input.GetAxis("Jump") * 8, 0);
                hasJumped = true;
            }
        }
    }

    private void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.name == "Floor" || collision.gameObject.name == "Block")
        {
            hasJumped = false;
        }
    }
}
